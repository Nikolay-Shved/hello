def main():
    print('\033[31m {}' .format("Hello!"))


if __name__ == '__main__':
     main()